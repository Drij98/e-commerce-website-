prerequisite
 
node and npm should be installed
stanserd require or any compatible version.
set path for environment and system variable.
npm version 6.0.1
node version v11.14.0


open ecommerce folder in vscode
open in terminal
do following:

step 1. cd .\client\
step 2. npm i
step 3. npm start

open split terminal 

step 1. cd .\server\
step 2. npm i
step 3. node .\server.js

website page will opean in a browser and you can login into it or you can see the home page if you
 require admin control let me know your id address i will give you th contol to add and remove listing from the website. 
 